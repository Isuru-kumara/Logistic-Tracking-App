import 'package:flutter/material.dart';
import 'package:tracking_app_master/pages/get_started_page.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: GetStartedPage(
        body: Center(
          child: Text('This is a vehicle Tracking App!'),
        ),
      ),
    );
  }
}