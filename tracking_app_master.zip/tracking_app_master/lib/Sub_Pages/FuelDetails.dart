import 'package:flutter/material.dart';

class FuelDetailsScreen extends StatelessWidget {
  const FuelDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            //to implement

          
          ],
          
        ),
      ),
    );
  }
}