import 'package:flutter/material.dart';

class FuelDetailsScreen extends StatelessWidget {
  const FuelDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var _fuelBillNumber;
    var _quantityController;
    var _costPerUnitController;
    var _OtherDetails;
    var _resetForm;
    
    return Scaffold(
      appBar: AppBar(title:const Text('fuel details!'),
      iconTheme:const IconThemeData(),
      actions: [
          IconButton(
            icon: const Icon(Icons.backpack_sharp),
            onPressed: () {
              // Add your code 
               const Text('go back!');
            },
          ),
        ],
      ),
      body: Center(
        child: Column(
          children: [
             Row(
               children: [
                const Text('lets start by gathering your billing info'),
                Image.asset('assest/images/fuel.jpeg')
               ],
             )
          ],
        ),
       const SizedBox(height: 10.0),
       const Column(
            children:[
              Row(
                children: [
                  Icon(IconData( Icons.favorite,
                         color: Colors.black12,
                          size: 2.0,)
                          ),
                  Text('secure bill details')
                ],
              ),

            ],
          ),
       const SizedBox(height: 8.0),
       Container(
        child: Form(
         // key: _formKey,
          child: Column(
            children: <Widget>[
              TextFormField(
                controller: _fuelBillNumber,
                decoration: const InputDecoration(labelText: 'bill number'),
                validator: (value) {
                  if (value?.isEmpty ?? true) {
                    return '';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _quantityController,
                decoration: const InputDecoration(labelText: 'quantity of fuel '),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value?.isEmpty ?? true) {
                    return 'l';
                  } else if (double.tryParse(value!) == null) {
                    return '';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _costPerUnitController,
                decoration: const InputDecoration(labelText: 'price'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value?.isEmpty ?? true) {
                    return 'RS';
                  } else if (double.tryParse(value!) == null) {
                    return '';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 05),
              TextFormField(
                controller: _OtherDetails,
                decoration: const InputDecoration(labelText: 'other details'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value?.isEmpty ?? true) {
                    return '';
                  } else if (double.tryParse(value!) == null) {
                    return '';
                  }
                  return null;
                },
              ),
             const SizedBox(height: 05),
             ElevatedButton(onPressed: _resetForm,
             child:const Text('refreshing details')
             )
            ],
          ),

       )
      ),
    ),
    );
  }
}
