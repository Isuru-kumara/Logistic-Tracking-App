import 'package:flutter/material.dart';
import 'package:tracking_app_master/pages/VehiclesDetailsPage.dart';

class DirectionDetailsScreen extends StatelessWidget {
  const DirectionDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            //To Implement
          ],  
  const SizedBox(height: 10.0),
  
      ElevatedButton(
            onPressed: () {
              Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => VehicleDetailsPage()));
            },
             style: ElevatedButton.styleFrom(
                 primary: Colors.blue, 
                 onPrimary: Colors.white, 
                 shadowColor: Colors.grey, 
                 elevation: 5, 
                 shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30), 
                 ),

              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15), 
              ),
                child:const Text('Track Vehicles'),
              ),
       ),
      ) ,
    );
   }
  }

