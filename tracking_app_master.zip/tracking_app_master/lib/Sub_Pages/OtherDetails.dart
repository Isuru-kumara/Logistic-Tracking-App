import 'package:flutter/material.dart';

class OtherDetailsScreen extends StatelessWidget {
  const OtherDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Center(
        child: Column(
          children: [
            //to implement
          ],
        )),
    );
  }
}