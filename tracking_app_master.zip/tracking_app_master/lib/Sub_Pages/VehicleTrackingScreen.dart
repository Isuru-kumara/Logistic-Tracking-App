import 'package:flutter/material.dart';

class TrackVehiclesScreen extends StatefulWidget {
  @override
  _TrackVehiclesScreenState createState() => _TrackVehiclesScreenState();
}

class _TrackVehiclesScreenState extends State<TrackVehiclesScreen> {
  GoogleMapController mapController;
  Location location = Location();
  LatLng currentLocation;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  void _onMapCreated(GoogleMapController controller) {
    setState(() {
      mapController = controller;
    });
  }

  void _getCurrentLocation() async {
    try {
      LocationData _locationData = await location.getLocation();
      setState(() {
        currentLocation = LatLng(_locationData.latitude, _locationData.longitude);
      });
    } catch (e) {
      print("Error getting current location: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Track Vehicles'),
      ),
      body: (currentLocation == null)
          ? Center(child: CircularProgressIndicator())
          : GoogleMap(
              onMapCreated: _onMapCreated,
              initialCameraPosition: CameraPosition(
                target: currentLocation,
                zoom: 15.0,
              ),
              markers: Set<Marker>.from([
                Marker(
                  markerId: MarkerId("currentLocation"),
                  position: currentLocation,
                  infoWindow: InfoWindow(title: 'Current Location'),
                ),
              ]),
            ),
    );
  }
}