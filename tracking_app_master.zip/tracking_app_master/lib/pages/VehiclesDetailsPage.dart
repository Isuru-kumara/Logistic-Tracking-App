import 'package:flutter/material.dart';

class VehicleDetailsPage extends StatelessWidget {
  const VehicleDetailsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: ListView(
          scrollDirection: Axis.vertical,
          children: const[
            ListTile(
               //vehicle 1 details
              leading:Image(image:),
              subtitle: Text(),
              onTap:,
  
            ),
            Divider(),

            ListTile(
              //vehicle 2 details
              leading:Image(image:),
              subtitle: Text(),
              onTap:,
            ),
            Divider(),

            ListTile(
              //vehicle 3 details
              leading:Image(image:),
              subtitle: Text(),
              onTap:,
            ),
            Divider(),

            ListTile(
              //vehicle 4 details
              leading:Image(image:),
              subtitle: Text(),
              onTap:,
            ),
            Divider(),

            ListTile(
              //vehicle 5 details
              leading:Image(image:),
              subtitle: Text(),
              onTap:,
            ),
            Divider(),
          ],
        ),
      ),
     
    );
  }
}