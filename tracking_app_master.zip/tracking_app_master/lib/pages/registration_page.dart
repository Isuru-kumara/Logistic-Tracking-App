import 'package:flutter/material.dart';
import 'package:tracking_app_master/pages/home_page.dart';

// ignore: camel_case_types
class Registration_page extends StatelessWidget {
  const Registration_page
({super.key, required Center body});

  @override
  Widget build(BuildContext context) {
    var usernameController;
    var emailController;
    var passwordController;

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            TextFormField(
              controller: usernameController,
              decoration: const InputDecoration(labelText: 'Username'),
            ),

            const SizedBox(height: 20.0),

            TextFormField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 20.0),
            TextFormField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),

            const SizedBox(height: 20.0),

            ElevatedButton(
              onPressed: () {
                //  user registration logic here
                String username = usernameController.text;
                String email    = emailController.text;
                String password = passwordController.text;
                // add validation and registration logic here
                Text('Username: $username, Email: $email, Password: $password');
              },
               style: ElevatedButton.styleFrom(
                 primary: Colors.blue, 
                 onPrimary: Colors.white, 
                 shadowColor: Colors.grey, 
                 elevation: 5, 
                 shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30), 
                 ),

              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15), 
              ),
              child: const Text('Register'),
            ),

            const SizedBox(height: 10.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Homepage()));
                },
                 style: ElevatedButton.styleFrom(
                 primary: Colors.blue, 
                 onPrimary: Colors.white, 
                 shadowColor: Colors.grey, 
                 elevation: 5, 
                 shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30), 
                 ),

              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15), 
              ),

       // Text Field in the Registration page;
        child:const Center(child:Text('Register Here!'),
          style: TextStyle(
              fontSize: 24.0,
              fontWeight: FontWeight.bold,
              color: Color.fromARGB(255, 34, 35, 36),
              fontStyle: FontStyle.italic,
              letterSpacing: 2.0,
              wordSpacing: 4.0,
              backgroundColor: Color.fromARGB(255, 62, 93, 196),
                ),
                ),
                ),
              ),
           ],
        ),
      )
    );
  }
}