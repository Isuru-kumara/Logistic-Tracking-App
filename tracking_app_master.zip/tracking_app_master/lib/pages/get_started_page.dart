import 'package:flutter/material.dart';
import 'package:tracking_app_master/pages/registration_page.dart';

class GetStartedPage extends StatelessWidget {
  const GetStartedPage({super.key, required Center body});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(height: 10.0),
          DecoratedBox(
           decoration: const BoxDecoration(),
           child: Image.asset('assets/images/FrontImg.png'),
          ),
         const Center(
             child:Text('By Using this App you can track your vehicle and get more details about your vehicle!',
                style: TextStyle(fontSize: 24.0),
            ),
           ),
        ],
      ),

  const SizedBox(height: 10.0),

  ElevatedButton(
    onPressed: () {
      Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const Registration_page(body: body)));
        },
       style: ElevatedButton.styleFrom(
         primary: Colors.blue, 
         onPrimary: Colors.white, 
         shadowColor: Colors.grey, 
         elevation: 5, 
         shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30), 
                 ),
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15), 
              ),
        child:const Text('Get Started'),
      ),
    );
  }
}