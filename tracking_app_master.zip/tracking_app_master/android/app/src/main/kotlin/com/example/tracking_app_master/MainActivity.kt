package com.example.tracking_app_master

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
